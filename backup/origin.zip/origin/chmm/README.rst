===============
Stock HMM comparison
===============

Stock price data is modelled with HMM. Decoded hidden states are compared to each other.
 

